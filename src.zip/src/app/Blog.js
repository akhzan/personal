import React, { Component } from 'react';

class Blog extends Component{
	render(){
		return (
			<h1>Ini blog</h1>
		)
	}
}

export default Blog;