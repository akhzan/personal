import React, { Component } from 'react';

import '../css/Viewer.css';

class Viewer extends Component{
	render(){
		return (
			<div className="viewer">
				<h1>View</h1>
			</div>
		)
	}
}

export default Viewer;